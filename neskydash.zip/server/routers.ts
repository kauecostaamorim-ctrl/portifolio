import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { storageCreateUploadUrl } from "./storage";

const clientInput = z.object({
  name: z.string().min(2).max(160),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().max(40).optional(),
  notes: z.string().max(2000).optional(),
});

const videoInput = z.object({
  title: z.string().min(2).max(220),
  description: z.string().max(5000).optional(),
  clientId: z.number().int().positive().optional(),
  category: z.enum(["square", "horizontal", "vertical", "before_after", "other"]).optional(),
  status: z.enum(["pending", "editing", "review", "delivered"]).optional(),
  sourceType: z.enum(["upload", "youtube", "portfolio"]).optional(),
  sourceUrl: z.string().url().optional(),
  fileKey: z.string().max(500).optional(),
  thumbnailKey: z.string().max(500).optional(),
  fileName: z.string().max(255).optional(),
  fileSize: z.number().nonnegative().optional(),
  mimeType: z.string().max(120).optional(),
  duration: z.number().int().nonnegative().optional(),
  aspectRatio: z.string().max(20).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  admin: router({
    dashboard: adminProcedure.query(() => db.getDashboardMetrics()),
    videos: router({
      list: adminProcedure.input(z.object({ search: z.string().optional(), clientId: z.number().int().positive().optional(), status: z.enum(["pending", "editing", "review", "delivered"]).optional() }).optional()).query(({ input }) => db.listVideos(input || {})),
      create: adminProcedure.input(videoInput).mutation(({ input }) => db.createVideo(input)),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: videoInput.partial() })).mutation(({ input }) => db.updateVideo(input.id, input.data)),
      remove: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => db.deleteVideo(input.id)),
    }),
    clients: router({
      list: adminProcedure.input(z.object({ search: z.string().optional() }).optional()).query(({ input }) => db.listClients(input?.search)),
      create: adminProcedure.input(clientInput).mutation(({ input }) => db.createClient(input)),
      update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: clientInput.partial().extend({ status: z.enum(["active", "paused", "archived"]).optional() }) })).mutation(({ input }) => db.updateClient(input.id, input.data)),
      remove: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => db.deleteClient(input.id)),
    }),
    createUpload: adminProcedure.input(z.object({ fileName: z.string().min(1).max(255), contentType: z.string().max(120), size: z.number().positive().max(10 * 1024 * 1024 * 1024) })).mutation(({ input }) => storageCreateUploadUrl(`videos/${input.fileName}`, input.contentType)),
  }),
});

export type AppRouter = typeof appRouter;
