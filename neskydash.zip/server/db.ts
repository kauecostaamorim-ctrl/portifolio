import { and, desc, eq, like, sql, type SQL } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { activityLogs, clients, InsertUser, users, videos } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && (process.env.DATABASE_URL || ENV.databaseUrl)) {
    try {
      _db = drizzle(process.env.DATABASE_URL || ENV.databaseUrl);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.email !== undefined) {
    const isAllowedAdmin = typeof user.email === "string" && user.email.toLowerCase() === "kauecostaamorim@gmail.com";
    values.role = isAllowedAdmin ? "admin" : "user";
    updateSet.role = values.role;
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= values.lastSignedIn;

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

const withFilters = (filters: { search?: string; clientId?: number; status?: "pending" | "editing" | "review" | "delivered" }) => {
  const clauses: SQL[] = [];
  if (filters.search) clauses.push(like(videos.title, `%${filters.search}%`));
  if (filters.clientId) clauses.push(eq(videos.clientId, filters.clientId));
  if (filters.status) clauses.push(eq(videos.status, filters.status));
  return clauses.length ? and(...clauses) : undefined;
};

export async function listVideos(filters: { search?: string; clientId?: number; status?: "pending" | "editing" | "review" | "delivered" } = {}) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(videos).where(withFilters(filters)).orderBy(desc(videos.createdAt));
}

export async function listClients(search?: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(clients).where(search ? like(clients.name, `%${search}%`) : undefined).orderBy(desc(clients.createdAt));
}

export async function createClient(input: { name: string; email?: string; phone?: string; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(clients).values({
    name: input.name,
    email: input.email || null,
    phone: input.phone || null,
    notes: input.notes || null,
  });
  await db.insert(activityLogs).values({ type: "client", message: `Cliente criado: ${input.name}` });
  return Number(result[0].insertId);
}

export async function updateClient(id: number, input: { name?: string; email?: string; phone?: string; status?: "active" | "paused" | "archived"; notes?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(clients).set({ ...input, updatedAt: new Date() }).where(eq(clients.id, id));
}

export async function deleteClient(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(clients).where(eq(clients.id, id));
}

export async function createVideo(input: {
  title: string;
  description?: string;
  clientId?: number;
  category?: "square" | "horizontal" | "vertical" | "before_after" | "other";
  status?: "pending" | "editing" | "review" | "delivered";
  sourceType?: "upload" | "youtube" | "portfolio";
  sourceUrl?: string;
  fileKey?: string;
  thumbnailKey?: string;
  fileName?: string;
  fileSize?: number;
  mimeType?: string;
  duration?: number;
  aspectRatio?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(videos).values({
    title: input.title,
    description: input.description || null,
    clientId: input.clientId || null,
    category: input.category || "other",
    status: input.status || "pending",
    sourceType: input.sourceType || "upload",
    sourceUrl: input.sourceUrl || null,
    fileKey: input.fileKey || null,
    thumbnailKey: input.thumbnailKey || null,
    fileName: input.fileName || null,
    fileSize: input.fileSize || null,
    mimeType: input.mimeType || null,
    duration: input.duration || null,
    aspectRatio: input.aspectRatio || null,
  });
  await db.insert(activityLogs).values({
    type: input.sourceType === "youtube" ? "youtube" : "upload",
    message: input.sourceType === "youtube" ? `Vídeo do YouTube cadastrado: ${input.title}` : `Vídeo enviado: ${input.title}`,
    videoId: Number(result[0].insertId),
    clientId: input.clientId || null,
  });
  return Number(result[0].insertId);
}

export async function updateVideo(id: number, input: { title?: string; description?: string; clientId?: number; category?: "square" | "horizontal" | "vertical" | "before_after" | "other"; status?: "pending" | "editing" | "review" | "delivered"; aspectRatio?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const deliveredAt = input.status === "delivered" ? new Date() : undefined;
  await db.update(videos).set({ ...input, deliveredAt, updatedAt: new Date() }).where(eq(videos.id, id));
  await db.insert(activityLogs).values({ type: "status", message: `Vídeo atualizado: ${input.title || `#${id}`}`, videoId: id });
}

export async function deleteVideo(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(videos).where(eq(videos.id, id));
}

export async function getDashboardMetrics() {
  const db = await getDb();
  if (!db) return { totalVideos: 0, totalClients: 0, storageBytes: 0, pendingVideos: 0, deliveredVideos: 0, recentVideos: [], activities: [] };
  const [videoCount] = await db.select({ count: sql<number>`count(*)` }).from(videos);
  const [clientCount] = await db.select({ count: sql<number>`count(*)` }).from(clients);
  const [storage] = await db.select({ bytes: sql<number>`coalesce(sum(${videos.fileSize}), 0)` }).from(videos);
  const [pending] = await db.select({ count: sql<number>`count(*)` }).from(videos).where(sql`${videos.status} <> 'delivered'`);
  const [delivered] = await db.select({ count: sql<number>`count(*)` }).from(videos).where(eq(videos.status, "delivered"));
  const recentVideos = await db.select().from(videos).orderBy(desc(videos.createdAt)).limit(5);
  const activities = await db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(6);
  return {
    totalVideos: Number(videoCount?.count || 0),
    totalClients: Number(clientCount?.count || 0),
    storageBytes: Number(storage?.bytes || 0),
    pendingVideos: Number(pending?.count || 0),
    deliveredVideos: Number(delivered?.count || 0),
    recentVideos,
    activities,
  };
}
