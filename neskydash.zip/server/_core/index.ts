import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createWriteStream, createReadStream } from "fs";
import { mkdir, rm } from "fs/promises";
import { tmpdir } from "os";
import { join } from "path";
import { PassThrough } from "stream";
import { once } from "events";
import { pipeline } from "stream/promises";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { sdk } from "./sdk";
import { ALLOWED_ADMIN_EMAIL } from "./trpc";
import { storageGetUploadUrl } from "../storage";

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.put("/api/admin/upload/chunk", async (req, res) => {
    let user;
    try {
      user = await sdk.authenticateRequest(req);
    } catch {
      return res.status(401).json({ error: "Authentication required" });
    }
    if (user.role !== "admin" || user.email?.toLowerCase() !== ALLOWED_ADMIN_EMAIL) return res.status(403).json({ error: "Admin access required" });
    const key = typeof req.query.key === "string" ? req.query.key : "";
    const chunk = Number(req.query.chunk);
    const totalChunks = Number(req.query.totalChunks);
    const totalSize = Number(req.query.totalSize);
    if (!key.startsWith("videos/") || key.includes("..") || !Number.isInteger(chunk) || chunk < 0 || !Number.isInteger(totalChunks) || totalChunks < 1 || chunk >= totalChunks || !Number.isSafeInteger(totalSize) || totalSize <= 0) return res.status(400).json({ error: "Invalid upload chunk" });
    const sessionDir = join(tmpdir(), "nesky-uploads", encodeURIComponent(key));
    const chunkPath = join(sessionDir, `${chunk}.part`);
    try {
      await mkdir(sessionDir, { recursive: true });
      await pipeline(req, createWriteStream(chunkPath));
      if (chunk < totalChunks - 1) return res.status(200).json({ ok: true, complete: false });
      const contentType = typeof req.headers["content-type"] === "string" ? req.headers["content-type"] : "application/octet-stream";
      const pass = new PassThrough();
      const uploadUrl = await storageGetUploadUrl(key);
      const uploadPromise = fetch(uploadUrl, { method: "PUT", headers: { "Content-Type": contentType, "Content-Length": String(totalSize) }, body: pass, duplex: "half" } as any);
      try {
        for (let index = 0; index < totalChunks; index += 1) {
          const part = createReadStream(join(sessionDir, `${index}.part`));
          for await (const data of part) {
            if (!pass.write(data)) await once(pass, "drain");
          }
        }
        pass.end();
        const upstream = await uploadPromise;
        if (!upstream.ok) return res.status(502).json({ error: `Storage upload failed (${upstream.status})` });
      } catch (error) {
        pass.destroy(error as Error);
        throw error;
      }
      return res.status(200).json({ ok: true, complete: true });
    } catch (error) {
      console.error("[Upload] Chunked proxy failed:", error);
      return res.status(500).json({ error: "Chunked upload failed" });
    } finally {
      if (chunk === totalChunks - 1) await rm(sessionDir, { recursive: true, force: true }).catch(() => undefined);
    }
  });
  app.put("/api/admin/upload", async (req, res) => {
    try {
      let user;
      try {
        user = await sdk.authenticateRequest(req);
      } catch {
        return res.status(401).json({ error: "Authentication required" });
      }
      if (user.role !== "admin" || user.email?.toLowerCase() !== ALLOWED_ADMIN_EMAIL) {
        return res.status(403).json({ error: "Admin access required" });
      }
      const key = typeof req.query.key === "string" ? req.query.key : "";
      if (!key.startsWith("videos/") || key.includes("..")) {
        return res.status(400).json({ error: "Invalid upload key" });
      }
      const contentType = typeof req.headers["content-type"] === "string" ? req.headers["content-type"] : "application/octet-stream";
      const contentLength = typeof req.headers["content-length"] === "string" ? req.headers["content-length"] : undefined;
      const uploadUrl = await storageGetUploadUrl(key);
      const upstream = await fetch(uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": contentType, ...(contentLength ? { "Content-Length": contentLength } : {}) },
        body: req as any,
        duplex: "half",
      } as any);
      if (!upstream.ok) {
        return res.status(502).json({ error: `Storage upload failed (${upstream.status})` });
      }
      return res.status(200).json({ ok: true });
    } catch (error) {
      console.error("[Upload] Proxy failed:", error);
      return res.status(500).json({ error: "Upload proxy failed" });
    }
  });
  registerOAuthRoutes(app);
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
