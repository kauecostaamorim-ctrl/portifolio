# TODO NESKY Portfolio + Painel

## Landing pública recriada

- [x] A página `/` preserva a estrutura pública analisada: cabeçalho com navegação, hero NESKY EDITOR, CTA de WhatsApp, CTA para trabalhos, faixa de especialidades, portfólio, antes/depois, serviços, processo, contato e rodapé.
- [x] A identidade visual pública usa fundo escuro, verde-limão fluorescente, tipografia Archivo/Archivo Black, etiquetas técnicas e linhas/timelines coerentes com a referência.
- [x] A galeria pública apresenta vídeos 1:1, 16:9 e 9:16; cada cartão abre um modal com reprodução e fechamento sem navegação destrutiva.
- [x] A navegação por âncoras, retorno ao topo, links externos e menu responsivo funcionam em desktop e mobile.

## Acesso administrativo

- [x] A rota `/admin` possui shell separado da landing e não altera as páginas públicas.
- [x] Somente a identidade autenticada com e-mail `kauecostaamorim@gmail.com` pode acessar dados e ações administrativas.
- [x] A autorização é verificada no servidor; usuários não autorizados recebem resposta de acesso negado mesmo que tentem chamar os procedimentos diretamente.
- [x] A sessão usa o fluxo de autenticação do projeto e não expõe credenciais secretas no frontend.

## Dashboard

- [x] O dashboard mostra total de vídeos cadastrados, total de clientes, armazenamento utilizado, vídeos recentes, vídeos pendentes e entregues.
- [x] O dashboard possui visualização de atividade com dados persistidos ou estados vazios honestos, sem inventar métricas de produção.

## Biblioteca e clientes

- [x] A biblioteca lista vídeos e permite pesquisa por nome, filtros por cliente, data e status, visualização e abertura do player.
- [x] Registros de vídeo podem ser excluídos com confirmação e os procedimentos server-side para atualização estão disponíveis.
- [x] Vídeos podem ser organizados por categoria ou pasta lógica.
- [x] O painel permite cadastrar clientes e consultar informações de contato e status.

## Upload e YouTube

- [x] O formulário de upload aceita formatos de vídeo comuns e exibe nome, tamanho, formato, progresso e associação ao cliente.
- [ ] O navegador agora envia em blocos de 8 MB, evitando o 413 do gateway e permitindo retomada durante a sessão; o multipart/resumível nativo no storage final ainda depende da conexão de um storage com multipart, como Cloudflare R2.
- [x] O painel permite cadastrar links do YouTube, validar a URL, salvar o identificador e usar o player oficial incorporado.
- [x] O sistema não baixa automaticamente vídeos protegidos do YouTube.

## Qualidade e entrega

- [x] `manus-routes.json` declara `/`, `/admin` e as rotas efetivamente implementadas.
- [x] O projeto passa por checagem TypeScript, testes automatizados e build de produção.
- [x] O painel é responsivo, mantém a identidade NESKY adaptada ao uso operacional e não contém botões decorativos sem comportamento definido.
- [x] Migrações do banco e integrações são documentadas no projeto antes do checkpoint.
