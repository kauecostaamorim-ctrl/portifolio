# Plano NESKY Portfolio + Painel

## Escopo aprovado

Recriar do zero o portfólio público NESKY com base na referência pública analisada, preservando sua estrutura, identidade visual e funcionalidades de navegação e reprodução. Adicionar um painel administrativo separado, sem alterar a experiência pública, com acesso exclusivo ao e-mail `kauecostaamorim@gmail.com`.

## Arquitetura

- **Frontend:** React + TypeScript + Wouter, com páginas públicas e rota administrativa separadas.
- **Servidor:** Express + tRPC do starter, mantendo autenticação Manus OAuth e procedimentos protegidos no servidor.
- **Persistência:** MySQL gerenciado do projeto via Drizzle ORM. O banco guarda clientes, vídeos, categorias, status, metadados e logs; não guarda bytes grandes de vídeo.
- **Arquivos:** Storage durável do projeto usando endereços estáveis `/manus-storage/<key>` e presign server-side quando o upload real for conectado. A primeira versão visual terá fluxo de upload preparado e estado local demonstrável; o upload de produção dependerá das credenciais/serviço de storage configurados.
- **YouTube:** salvar URL/ID e renderizar player oficial incorporado; nunca baixar automaticamente o vídeo.
- **Autorização:** autenticação Manus OAuth, verificação server-side do e-mail permitido e procedures protegidas. A interface também oculta a rota administrativa para usuários não autorizados, mas a segurança efetiva fica no servidor.

## Estrutura de projeto

- `client/src/pages/Home.tsx`: landing pública completa.
- `client/src/pages/Admin.tsx`: shell do painel, dashboard, biblioteca, clientes e upload.
- `client/src/components/`: componentes de navegação, modais, cartões e UI reutilizável.
- `client/src/index.css`: tokens NESKY, tipografia, responsividade e movimento visual.
- `server/routers.ts`: queries/mutations públicas e protegidas.
- `server/db.ts`: queries de usuários, clientes, vídeos e atividade.
- `drizzle/schema.ts`: tabelas e tipos persistidos.
- `public/manus-routes.json`: rotas públicas e administrativas.

## Design

### Direções consideradas

1. **Editorial industrial neon** — 0,07: preto técnico, verde-limão, tipografia de pôster e detalhes de timeline.
2. **Studio control room** — 0,08: painel mais denso, azul elétrico e cartões de operação audiovisual.
3. **Minimalismo brutalista** — 0,06: grandes massas tipográficas, bordas secas e contraste monocromático.

### Direção escolhida: editorial industrial neon

- **Movimento:** portfólio editorial de pós-produção audiovisual com linguagem de estação de edição.
- **Princípios:** contraste alto; informação em camadas; ritmo visual; ações diretas.
- **Filosofia de cor:** preto reduz ruído e faz o verde-limão funcionar como marcador de status, ação e energia de edição. Cinzas organizam a hierarquia sem competir com os vídeos.
- **Layout:** hero assimétrico em duas colunas; seções guiadas por linhas horizontais e etiquetas numeradas; painel administrativo com sidebar fixa e conteúdo em trilhas.
- **Assinaturas:** verde-limão fluorescente; etiquetas monoespaçadas; timelines, timecodes e faixas corridas.
- **Interação:** hover curto e preciso; cartões de vídeo abrem modal; ações primárias têm alto contraste; estados de upload usam progresso realista e mensagens claras.
- **Animação:** faixa de especialidades em loop linear; timeline com playhead contínuo; entrada suave das seções; sem animações longas ou decorativas no painel.
- **Tipografia:** Archivo para corpo e navegação; Archivo Black para títulos; mono para metadados e rótulos técnicos.
- **Essência:** edição que transforma material bruto em conteúdo pronto para publicar. Direta, técnica e inquieta.
- **Voz:** CTAs curtos e específicos. Exemplos: “Chamar no WhatsApp” e “Abrir biblioteca”.
- **Marca:** wordmark NESKY_EDITOR em caixa alta, com separador de underscore e tratamento de outline no segundo termo.
- **Cor proprietária:** `#D4FF00`.

## Fases de implementação

1. Substituir o starter pela landing pública responsiva e fiel à referência.
2. Criar o shell administrativo separado e o bloqueio de autorização.
3. Criar schema e queries para clientes, vídeos, categorias e atividades.
4. Implementar dashboard, biblioteca, filtros, modal de vídeo e formulário de clientes.
5. Implementar estado visual de upload e estrutura server-side para storage.
6. Implementar cadastro de links do YouTube com player oficial.
7. Validar rotas, build, diagnósticos, responsividade e preservação da página pública.
8. Registrar checkpoint somente após a validação.
