import { FormEvent, useMemo, useState, type ReactNode } from "react";
import { BarChart3, CheckCircle2, CloudUpload, FileVideo, FolderOpen, LayoutDashboard, LogOut, Menu, Play, Plus, Search, ShieldCheck, Trash2, Users, X, Youtube } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

const ALLOWED_EMAIL = "kauecostaamorim@gmail.com";

type Tab = "overview" | "videos" | "clients" | "uploads";
const statusLabels: Record<string, string> = { pending: "Pendente", editing: "Em edição", review: "Em revisão", delivered: "Entregue" };
const categoryLabels: Record<string, string> = { square: "1:1", horizontal: "16:9", vertical: "9:16", before_after: "Antes/depois", other: "Outro" };

function formatBytes(bytes = 0) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / Math.pow(1024, index)).toFixed(index ? 1 : 0)} ${units[index]}`;
}

function extractYoutubeId(value: string) {
  const match = value.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([^?&/]+)/);
  return match?.[1] || "";
}

function AdminGate() {
  const { loading } = useAuth({ redirectOnUnauthenticated: true });
  return <div className="admin-gate"><div className="admin-gate-mark"><ShieldCheck size={23} /></div><p>{loading ? "Verificando sessão..." : "Redirecionando para o login..."}</p></div>;
}

export default function Admin() {
  const auth = useAuth({ redirectOnUnauthenticated: true });
  const [tab, setTab] = useState<Tab>("overview");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [clientForm, setClientForm] = useState({ name: "", email: "", phone: "", notes: "" });
  const [videoForm, setVideoForm] = useState({ title: "", clientId: "", category: "other", status: "pending" });
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [youtubeTitle, setYoutubeTitle] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadMessage, setUploadMessage] = useState("");

  const isAllowed = auth.user?.email?.toLowerCase() === ALLOWED_EMAIL;
  const utils = trpc.useUtils();
  const dashboard = trpc.admin.dashboard.useQuery(undefined, { enabled: isAllowed, retry: false });
  const videos = trpc.admin.videos.list.useQuery({ search: search || undefined }, { enabled: isAllowed, retry: false });
  const clients = trpc.admin.clients.list.useQuery({ search: undefined }, { enabled: isAllowed, retry: false });
  const createClient = trpc.admin.clients.create.useMutation({ onSuccess: () => { setClientForm({ name: "", email: "", phone: "", notes: "" }); void utils.admin.clients.list.invalidate(); void utils.admin.dashboard.invalidate(); } });
  const removeClient = trpc.admin.clients.remove.useMutation({ onSuccess: () => { void utils.admin.clients.list.invalidate(); void utils.admin.dashboard.invalidate(); } });
  const createVideo = trpc.admin.videos.create.useMutation({ onSuccess: () => { setVideoForm({ title: "", clientId: "", category: "other", status: "pending" }); setSelectedFile(null); setYoutubeUrl(""); setYoutubeTitle(""); void utils.admin.videos.list.invalidate(); void utils.admin.dashboard.invalidate(); } });
  const removeVideo = trpc.admin.videos.remove.useMutation({ onSuccess: () => { void utils.admin.videos.list.invalidate(); void utils.admin.dashboard.invalidate(); } });
  const createUpload = trpc.admin.createUpload.useMutation();

  const clientOptions = clients.data || [];
  const recent = dashboard.data?.recentVideos || [];
  const activity = dashboard.data?.activities || [];
  const selectedClientName = useMemo(() => new Map(clientOptions.map(client => [client.id, client.name])), [clientOptions]);

  if (auth.loading) return <AdminGate />;
  if (!auth.isAuthenticated) return <AdminGate />;
  if (!isAllowed) return <div className="admin-gate"><div className="admin-gate-mark danger"><X size={23} /></div><h1>Acesso restrito</h1><p>Este painel está disponível somente para o administrador autorizado.</p><span>{auth.user?.email || "Conta não identificada"}</span><button className="button button-ghost" onClick={() => void auth.logout()}>Sair</button></div>;

  const switchTab = (next: Tab) => { setTab(next); setSidebarOpen(false); };

  const handleClientSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!clientForm.name.trim()) return;
    await createClient.mutateAsync(clientForm);
  };

  const uploadWithProgress = async (url: string, file: File) => {
    const chunkSize = 8 * 1024 * 1024;
    const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));
    for (let index = 0; index < totalChunks; index += 1) {
      const start = index * chunkSize;
      const chunk = file.slice(start, Math.min(start + chunkSize, file.size));
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const separator = url.includes("?") ? "&" : "?";
        xhr.open("PUT", `${url}${separator}chunk=${index}&totalChunks=${totalChunks}&totalSize=${file.size}`);
        xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
        xhr.upload.onprogress = event => {
          if (event.lengthComputable) setUploadProgress(Math.round(((index + event.loaded / event.total) / totalChunks) * 100));
        };
        xhr.onload = () => xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error(`Upload falhou (${xhr.status})`));
        xhr.onerror = () => reject(new Error("Falha de rede durante o upload"));
        xhr.send(chunk);
      });
    }
  };

  const handleFileUpload = async (event: FormEvent) => {
    event.preventDefault();
    if (!selectedFile) return;
    try {
      setUploadMessage("Preparando upload...");
      setUploadProgress(0);
      const signed = await createUpload.mutateAsync({ fileName: selectedFile.name, contentType: selectedFile.type || "video/mp4", size: selectedFile.size });
      setUploadMessage("Enviando arquivo para o storage...");
      await uploadWithProgress(signed.proxyUploadUrl || signed.uploadUrl, selectedFile);
      await createVideo.mutateAsync({ title: videoForm.title || selectedFile.name.replace(/\.[^.]+$/, ""), clientId: videoForm.clientId ? Number(videoForm.clientId) : undefined, category: videoForm.category as "square" | "horizontal" | "vertical" | "before_after" | "other", status: videoForm.status as "pending" | "editing" | "review" | "delivered", sourceType: "upload", fileKey: signed.key, fileName: selectedFile.name, fileSize: selectedFile.size, mimeType: selectedFile.type || "application/octet-stream" });
      setUploadMessage("Upload concluído e vídeo cadastrado.");
      setUploadProgress(100);
    } catch (error) {
      setUploadMessage(error instanceof Error ? error.message : "Não foi possível concluir o upload.");
    }
  };

  const handleYoutubeSubmit = async (event: FormEvent) => {
    event.preventDefault();
    const videoId = extractYoutubeId(youtubeUrl);
    if (!videoId) { setUploadMessage("Insira uma URL válida do YouTube."); return; }
    await createVideo.mutateAsync({ title: youtubeTitle || `Vídeo YouTube ${videoId}`, sourceType: "youtube", sourceUrl: `https://www.youtube.com/watch?v=${videoId}`, category: "other", status: "pending" });
    setUploadMessage("Link do YouTube cadastrado.");
  };

  const renderOverview = () => <>
    <div className="admin-page-head"><div><p className="admin-eyebrow">Visão geral / 01</p><h1>Dashboard</h1><p className="admin-subtitle">Acompanhe o fluxo de trabalho da Nesky em um só lugar.</p></div><button className="admin-action" onClick={() => switchTab("uploads")}><Plus size={16} /> Novo vídeo</button></div>
    <div className="metric-grid"><Metric icon={<FileVideo size={19} />} label="Vídeos cadastrados" value={dashboard.data?.totalVideos ?? 0} accent="lime" /><Metric icon={<Users size={19} />} label="Clientes ativos" value={dashboard.data?.totalClients ?? 0} accent="blue" /><Metric icon={<CloudUpload size={19} />} label="Armazenamento usado" value={formatBytes(dashboard.data?.storageBytes)} accent="violet" /><Metric icon={<CheckCircle2 size={19} />} label="Entregas concluídas" value={dashboard.data?.deliveredVideos ?? 0} accent="lime" /></div>
    <div className="admin-grid-two"><section className="admin-panel"><div className="panel-head"><div><span className="panel-kicker">Fila de trabalho</span><h2>Vídeos recentes</h2></div><button className="text-action" onClick={() => switchTab("videos")}>Abrir biblioteca <ArrowSmall /></button></div><div className="recent-list">{recent.length ? recent.map(video => <div className="recent-row" key={video.id}><div className="recent-thumb"><Play size={13} fill="currentColor" /></div><div><strong>{video.title}</strong><span>{video.createdAt ? new Date(video.createdAt).toLocaleDateString("pt-BR") : "Agora"} · {categoryLabels[video.category] || "Outro"}</span></div><StatusPill value={video.status} /></div>) : <EmptyState text="Nenhum vídeo cadastrado ainda." />}</div></section><section className="admin-panel activity-panel"><div className="panel-head"><div><span className="panel-kicker">Rastro de operação</span><h2>Atividade</h2></div><BarChart3 size={18} className="muted-icon" /></div>{activity.length ? activity.map(item => <div className="activity-row" key={item.id}><span className="activity-dot" /><div><strong>{item.message}</strong><span>{item.createdAt ? new Date(item.createdAt).toLocaleString("pt-BR") : "Agora"}</span></div></div>) : <EmptyState text="As atividades aparecerão aqui." />}</section></div>
    <section className="admin-panel status-panel"><div className="panel-head"><div><span className="panel-kicker">Produção</span><h2>Status dos projetos</h2></div><span className="storage-readout">{dashboard.data?.pendingVideos ?? 0} pendentes</span></div><div className="status-bars"><StatusBar label="Pendentes / em andamento" value={dashboard.data?.pendingVideos ?? 0} total={(dashboard.data?.totalVideos || 1)} tone="lime" /><StatusBar label="Entregues" value={dashboard.data?.deliveredVideos ?? 0} total={(dashboard.data?.totalVideos || 1)} tone="blue" /></div></section>
  </>;

  const renderVideos = () => <><div className="admin-page-head"><div><p className="admin-eyebrow">Conteúdo / 02</p><h1>Biblioteca</h1><p className="admin-subtitle">Arquivos, links e entregas organizados por projeto.</p></div><button className="admin-action" onClick={() => switchTab("uploads")}><CloudUpload size={16} /> Upload</button></div><div className="library-toolbar"><label className="search-field"><Search size={16} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Pesquisar por nome..." /></label><button className="filter-chip active">Todos</button><button className="filter-chip">Pendentes</button><button className="filter-chip">Entregues</button></div><div className="video-library">{videos.data?.length ? videos.data.map(video => <article className="library-card" key={video.id}><div className="library-preview">{video.sourceType === "youtube" ? <div className="youtube-poster small"><Youtube size={20} /><span>YouTube</span></div> : <div><FileVideo size={28} /><span>{video.aspectRatio || categoryLabels[video.category] || "Vídeo"}</span></div>}<span className="library-format">{categoryLabels[video.category]}</span></div><div className="library-card-body"><div><span className="panel-kicker">#{String(video.id).padStart(3, "0")} · {video.sourceType === "youtube" ? "LINK" : "ARQUIVO"}</span><h3>{video.title}</h3><p>{video.fileName || video.sourceUrl || "Sem arquivo associado"}</p></div><div className="library-meta"><StatusPill value={video.status} /><span>{formatBytes(video.fileSize || 0)}</span></div><div className="library-actions"><button className="text-action">Editar</button><button className="danger-action" onClick={() => window.confirm("Excluir este registro?") && removeVideo.mutate({ id: video.id })}><Trash2 size={14} /> Excluir</button></div></div></article>) : <EmptyState text="Nenhum vídeo encontrado. Cadastre um upload ou link do YouTube." />}</div></>;

  const renderClients = () => <><div className="admin-page-head"><div><p className="admin-eyebrow">Relacionamento / 03</p><h1>Clientes</h1><p className="admin-subtitle">Pessoas e projetos associados aos seus vídeos.</p></div></div><div className="admin-grid-two clients-layout"><section className="admin-panel"><div className="panel-head"><div><span className="panel-kicker">Nova ficha</span><h2>Cadastrar cliente</h2></div><Users size={18} className="muted-icon" /></div><form className="stack-form" onSubmit={handleClientSubmit}><input value={clientForm.name} onChange={event => setClientForm({ ...clientForm, name: event.target.value })} placeholder="Nome do cliente" required /><input type="email" value={clientForm.email} onChange={event => setClientForm({ ...clientForm, email: event.target.value })} placeholder="E-mail" /><input value={clientForm.phone} onChange={event => setClientForm({ ...clientForm, phone: event.target.value })} placeholder="Telefone / WhatsApp" /><textarea value={clientForm.notes} onChange={event => setClientForm({ ...clientForm, notes: event.target.value })} placeholder="Observações" rows={4} /><button className="admin-action full" disabled={createClient.isPending}><Plus size={16} /> {createClient.isPending ? "Salvando..." : "Salvar cliente"}</button></form></section><section className="admin-panel"><div className="panel-head"><div><span className="panel-kicker">Base de clientes</span><h2>Ativos</h2></div><span className="storage-readout">{clientOptions.length} registros</span></div><div className="client-list">{clientOptions.length ? clientOptions.map(client => <div className="client-row" key={client.id}><div className="client-avatar">{client.name.slice(0, 1).toUpperCase()}</div><div><strong>{client.name}</strong><span>{client.email || client.phone || "Sem contato cadastrado"}</span></div><button className="icon-button subtle" aria-label={`Excluir ${client.name}`} onClick={() => window.confirm("Excluir este cliente?") && removeClient.mutate({ id: client.id })}><Trash2 size={15} /></button></div>) : <EmptyState text="Cadastre o primeiro cliente para começar." />}</div></section></div></>;

  const renderUploads = () => <><div className="admin-page-head"><div><p className="admin-eyebrow">Entrada / 04</p><h1>Adicionar vídeo</h1><p className="admin-subtitle">Envie um arquivo ou registre um vídeo do YouTube sem fazer download.</p></div></div><div className="admin-grid-two upload-layout"><section className="admin-panel"><div className="panel-head"><div><span className="panel-kicker">Arquivo local</span><h2>Upload de vídeo</h2></div><CloudUpload size={18} className="muted-icon" /></div><form className="stack-form" onSubmit={handleFileUpload}><label className="dropzone"><input type="file" accept="video/mp4,video/quicktime,video/x-matroska,video/*" onChange={event => setSelectedFile(event.target.files?.[0] || null)} /><CloudUpload size={27} /><strong>{selectedFile ? selectedFile.name : "Clique para escolher um vídeo"}</strong><span>MP4, MOV, MKV e outros formatos · envio direto para storage privado</span></label><input value={videoForm.title} onChange={event => setVideoForm({ ...videoForm, title: event.target.value })} placeholder="Título do vídeo (opcional)" /><div className="form-row"><select value={videoForm.category} onChange={event => setVideoForm({ ...videoForm, category: event.target.value })}><option value="other">Categoria</option><option value="square">Quadrado 1:1</option><option value="horizontal">Horizontal 16:9</option><option value="vertical">Vertical 9:16</option><option value="before_after">Antes / Depois</option></select><select value={videoForm.clientId} onChange={event => setVideoForm({ ...videoForm, clientId: event.target.value })}><option value="">Cliente</option>{clientOptions.map(client => <option key={client.id} value={client.id}>{client.name}</option>)}</select></div><button className="admin-action full" disabled={!selectedFile || createUpload.isPending || createVideo.isPending}><CloudUpload size={16} /> {createUpload.isPending || createVideo.isPending ? "Processando..." : "Iniciar upload"}</button>{uploadProgress > 0 && <div className="upload-progress"><div><span>Progresso</span><b>{uploadProgress}%</b></div><i><em style={{ width: `${uploadProgress}%` }} /></i></div>}{uploadMessage && <p className="form-message">{uploadMessage}</p>}</form></section><section className="admin-panel"><div className="panel-head"><div><span className="panel-kicker">Fonte externa</span><h2>Importar YouTube</h2></div><Youtube size={18} className="muted-icon" /></div><form className="stack-form" onSubmit={handleYoutubeSubmit}><div className="youtube-note"><Youtube size={18} /><p>O vídeo será exibido pelo player oficial. Nenhum arquivo protegido será baixado.</p></div><input value={youtubeUrl} onChange={event => setYoutubeUrl(event.target.value)} placeholder="https://youtube.com/watch?v=..." required /><input value={youtubeTitle} onChange={event => setYoutubeTitle(event.target.value)} placeholder="Título (opcional)" /><button className="admin-action full" disabled={createVideo.isPending}><Youtube size={16} /> Cadastrar link</button></form><div className="upload-info"><span><ShieldCheck size={15} /> Storage privado</span><span><FolderOpen size={15} /> Metadados no banco</span><span><BarChart3 size={15} /> Progresso em tempo real</span></div></section></div></>;

  return <div className="admin-shell"><aside className={`admin-sidebar ${sidebarOpen ? "open" : ""}`}><div className="admin-brand"><a href="/" className="wordmark">NESKY<span>_EDITOR</span></a><span>PAINEL</span><button className="sidebar-close" onClick={() => setSidebarOpen(false)}><X size={18} /></button></div><nav><button className={tab === "overview" ? "active" : ""} onClick={() => switchTab("overview")}><LayoutDashboard size={17} /> Visão geral</button><button className={tab === "videos" ? "active" : ""} onClick={() => switchTab("videos")}><FileVideo size={17} /> Biblioteca</button><button className={tab === "clients" ? "active" : ""} onClick={() => switchTab("clients")}><Users size={17} /> Clientes</button><button className={tab === "uploads" ? "active" : ""} onClick={() => switchTab("uploads")}><CloudUpload size={17} /> Adicionar vídeo</button></nav><div className="sidebar-bottom"><div className="admin-identity"><div className="client-avatar">K</div><div><strong>Administrador</strong><span>{auth.user?.email}</span></div></div><button className="logout-button" onClick={() => void auth.logout()}><LogOut size={16} /> Sair</button></div></aside><div className="admin-main"><header className="admin-topbar"><button className="sidebar-trigger" onClick={() => setSidebarOpen(true)}><Menu size={19} /></button><span>NESKY / {tab === "overview" ? "DASHBOARD" : tab.toUpperCase()}</span><a href="/" target="_blank" rel="noreferrer">Ver site público <ArrowSmall /></a></header><div className="admin-content">{tab === "overview" && renderOverview()}{tab === "videos" && renderVideos()}{tab === "clients" && renderClients()}{tab === "uploads" && renderUploads()}</div></div></div>;
}

function Metric({ icon, label, value, accent }: { icon: ReactNode; label: string; value: string | number; accent: string }) { return <div className={`metric-card ${accent}`}><span className="metric-icon">{icon}</span><span>{label}</span><strong>{value}</strong><small>Atualizado agora</small></div>; }
function StatusPill({ value }: { value: string }) { return <span className={`status-pill ${value}`}>{statusLabels[value] || value}</span>; }
function StatusBar({ label, value, total, tone }: { label: string; value: number; total: number; tone: string }) { return <div className="status-bar"><div><span>{label}</span><b>{value}</b></div><i><em className={tone} style={{ width: `${Math.min(100, Math.round((value / total) * 100))}%` }} /></i></div>; }
function EmptyState({ text }: { text: string }) { return <div className="empty-state"><span>—</span><p>{text}</p></div>; }
function ArrowSmall() { return <span aria-hidden="true">↗</span>; }
