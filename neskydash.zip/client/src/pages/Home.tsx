import { useEffect, useState } from "react";
import { ArrowUpRight, Check, Menu, Play, X } from "lucide-react";

type PortfolioItem = {
  title: string;
  label: string;
  meta: string;
  ratio: "square" | "horizontal" | "vertical";
  src?: string;
  youtubeId?: string;
};

const timelineSrc = "https://media.base44.com/videos/public/user_6ad1634bb24d6596d118f321/dd9c64688_timeline.mp4";

const portfolio: PortfolioItem[] = [
  { title: "Vídeo", label: "VÍDEO", meta: "1:1 · 0:51", ratio: "square", src: timelineSrc },
  { title: "Vídeo", label: "VÍDEO", meta: "1:1 · 0:35", ratio: "square", src: "https://media.base44.com/videos/public/user_6ad1634bb24d6596d118f321/a7bf24d86_arquivodochat.mp4" },
  { title: "Vídeo", label: "VÍDEO", meta: "16:9 · 1:25", ratio: "horizontal", src: "https://media.base44.com/videos/public/6ad6c746d74dc000058d1e39/d40652771_alanzoka.mp4" },
  { title: "Vídeo", label: "VÍDEO", meta: "16:9", ratio: "horizontal", youtubeId: "gYUjPfZ7q_Y" },
  { title: "Corte", label: "CORTE", meta: "9:16 · 0:51", ratio: "vertical", src: "https://media.base44.com/videos/public/user_6ad1634bb24d6596d118f321/503c9b9a4_video1ninja.mp4" },
  { title: "Corte", label: "CORTE", meta: "9:16 · 1:02", ratio: "vertical", src: "https://media.base44.com/videos/public/user_6ad1634bb24d6596d118f321/ed8d6fe0f_corte1.mp4" },
  { title: "Corte", label: "CORTE", meta: "9:16 · 1:01", ratio: "vertical", src: "https://media.base44.com/videos/public/user_6ad1634bb24d6596d118f321/32e480c8b_corte3.mp4" },
];

function MediaPreview({ item, onOpen }: { item: PortfolioItem; onOpen: () => void }) {
  return (
    <button className={`work-card work-card-${item.ratio}`} onClick={onOpen} aria-label={`Abrir ${item.title} ${item.meta}`}>
      <div className="work-media">
        {item.youtubeId ? (
          <div className="youtube-poster"><Play size={22} fill="currentColor" /><span>PLAYER YOUTUBE</span></div>
        ) : (
          <video src={item.src} muted autoPlay loop playsInline preload="metadata" />
        )}
        <span className="work-label">{item.label}</span>
        <span className="work-meta">{item.meta}</span>
        <span className="work-open"><ArrowUpRight size={15} /></span>
      </div>
    </button>
  );
}

function VideoModal({ item, onClose }: { item: PortfolioItem; onClose: () => void }) {
  return (
    <div className="video-modal-backdrop" role="dialog" aria-modal="true" aria-label={`${item.title} ${item.meta}`} onClick={onClose}>
      <div className="video-modal" onClick={event => event.stopPropagation()}>
        <div className="video-modal-head"><span>{item.label} · {item.meta}</span><button className="icon-button" onClick={onClose} aria-label="Fechar"><X size={18} /></button></div>
        {item.youtubeId ? (
          <iframe className="video-player" src={`https://www.youtube.com/embed/${item.youtubeId}?rel=0`} title="Vídeo do YouTube" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
        ) : (
          <video className="video-player" src={item.src} controls autoPlay playsInline />
        )}
      </div>
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState<PortfolioItem | null>(null);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => event.key === "Escape" && setSelected(null);
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell" id="top">
      <header className="site-header">
        <a className="wordmark" href="#top" onClick={closeMenu}>NESKY<span>_EDITOR</span></a>
        <button className="mobile-menu-button" onClick={() => setMenuOpen(value => !value)} aria-label="Abrir menu">{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
        <nav className={`site-nav ${menuOpen ? "is-open" : ""}`}>
          <a href="#trabalhos" onClick={closeMenu}>Trabalhos</a>
          <a href="#antes-depois" onClick={closeMenu}>Antes / Depois</a>
          <a href="#servicos" onClick={closeMenu}>O que eu faço</a>
          <a href="#processo" onClick={closeMenu}>Processo</a>
          <a href="#contato" onClick={closeMenu}>Contato</a>
        </nav>
        <a className="header-cta" href="https://wa.me/5511986890206" target="_blank" rel="noreferrer">Chamar no WhatsApp <ArrowUpRight size={14} /></a>
      </header>

      <main>
        <section className="hero section-pad">
          <div className="hero-copy">
            <p className="eyebrow"><span className="live-dot" /> Disponível para novos projetos</p>
            <h1><span>NESKY</span><em>EDITOR</em></h1>
            <p className="hero-description">Edito vídeos longos para YouTube e cortes verticais para TikTok, Reels e Shorts — ritmo, corte limpo e legendas que seguram a atenção.</p>
            <div className="hero-actions"><a className="button button-primary" href="https://wa.me/5511986890206" target="_blank" rel="noreferrer">Chamar no WhatsApp <ArrowUpRight size={16} /></a><a className="button button-ghost" href="#trabalhos">Ver trabalhos</a></div>
            <div className="hero-tags"><span>YouTube · longos</span><span>TikTok · Reels · Shorts</span></div>
            <a className="scroll-cue" href="#trabalhos">↓&nbsp; Rolar pra ver os trabalhos</a>
          </div>
          <div className="timeline-window">
            <div className="window-bar"><span className="window-dots"><i /><i /><i /></span><span>TIMELINE.MP4</span><b>00:00:02:03</b></div>
            <div className="timeline-preview"><video src={timelineSrc} muted autoPlay loop playsInline /></div>
            <div className="timeline-tracks"><span>PREVIEW</span>{["V1", "V2", "V3"].map((track, index) => <div className="track-row" key={track}><b>{track}</b><i style={{ width: `${68 + index * 7}%` }} /><i style={{ width: `${33 + index * 12}%` }} /></div>)}</div>
          </div>
        </section>

        <div className="marquee"><div className="marquee-track">{Array.from({ length: 2 }).flatMap((_, group) => ["Vídeos longos", "YouTube", "Cortes verticais", "TikTok", "Reels", "Shorts", "Ritmo", "Legendas", "Finalização"].map((term, index) => <span key={`${group}-${index}`}>{term}<b>◆</b></span>))}</div></div>

        <section id="trabalhos" className="section-pad portfolio-section">
          <div className="section-kicker"><span>01</span><i /> Portfólio</div>
          <div className="section-heading-row"><h2>Trabalhos</h2><span>Seleção de cortes e projetos</span></div>
          <div className="portfolio-group"><div className="group-head"><h3>Vídeos</h3><span>Formato 1:1</span></div><div className="work-grid square-grid">{portfolio.slice(0, 2).map(item => <MediaPreview key={item.meta} item={item} onOpen={() => setSelected(item)} />)}<a className="available-card" href="https://wa.me/5511986890206" target="_blank" rel="noreferrer"><span>Disponível</span><strong>Tem um vídeo esperando edição?</strong><em>Chamar no WhatsApp <ArrowUpRight size={13} /></em></a></div></div>
          <div className="portfolio-group"><div className="group-head"><h3>Vídeos horizontais</h3><span>Formato 16:9</span></div><div className="work-grid horizontal-grid">{portfolio.slice(2, 4).map(item => <MediaPreview key={item.meta} item={item} onOpen={() => setSelected(item)} />)}</div></div>
          <div className="portfolio-group"><div className="group-head"><h3>Cortes verticais</h3><span>9:16 · TikTok, Reels e Shorts</span></div><div className="work-grid vertical-grid">{portfolio.slice(4).map(item => <MediaPreview key={item.meta} item={item} onOpen={() => setSelected(item)} />)}</div></div>
        </section>

        <section id="antes-depois" className="section-pad before-section">
          <div className="section-kicker"><span>02</span><i /> Processo</div>
          <div className="before-layout"><div><h2>Antes e depois</h2><p>O material bruto chega cru: longo, sem ritmo e com sobra de tudo. É aqui que o vídeo vira conteúdo — corte na hora certa, áudio limpo e finalização pronta pra publicar.</p><div className="feature-list"><span>Ritmo</span><span>Corte</span><span>Finalização</span></div></div><div className="before-video"><video src="https://media.base44.com/videos/public/user_6ad1634bb24d6596d118f321/f6592d192_antesdepoisa.mp4" controls muted playsInline /><div className="before-labels"><span>Antes</span><span>Depois</span></div></div></div>
        </section>

        <section id="servicos" className="section-pad services-section"><div className="section-kicker"><span>03</span><i /> Serviços</div><div className="section-heading-row"><h2>O que eu faço</h2><span>Do material bruto ao arquivo pronto</span></div><div className="service-list"><article><span className="service-number">01</span><div><h3>Vídeos longos para YouTube</h3><p>Do material bruto ao arquivo pronto pra subir. Edição com ritmo, sem partes mortas, pra segurar quem assiste até o final.</p><ul><li><Check size={14} /> Corte e ritmo do material bruto</li><li><Check size={14} /> Trilha e ajuste de áudio</li><li><Check size={14} /> Finalização em 16:9</li></ul></div></article><article><span className="service-number">02</span><div><h3>Cortes verticais</h3><p>Aquele momento bom do vídeo virando conteúdo pro feed: corte rápido, gancho na frente e legenda na tela.</p><ul><li><Check size={14} /> Formato 9:16 pra TikTok, Reels e Shorts</li><li><Check size={14} /> Gancho nos primeiros segundos</li><li><Check size={14} /> Legendas e cortes rápidos</li></ul></div></article></div></section>

        <section id="processo" className="section-pad process-section"><div className="section-kicker"><span>04</span><i /> Como funciona</div><div className="section-heading-row"><h2>Do material bruto à entrega</h2><span>Um fluxo simples e direto</span></div><div className="process-grid">{[["01", "Briefing", "Você me manda o material e a referência do que quer."], ["02", "Edição", "Monto o vídeo: corte, ritmo, trilha e finalização."], ["03", "Revisão", "Você assiste e me diz o que quer ajustar."], ["04", "Entrega", "Arquivo pronto pra postar, no formato combinado."]].map(([number, title, text]) => <article key={number}><span>{number}</span><h3>{title}</h3><p>{text}</p></article>)}</div><div className="export-line"><span>Exportar projeto</span><b>100%</b></div></section>

        <section id="contato" className="section-pad contact-section"><div className="contact-card"><p className="eyebrow"><span className="live-dot" /> Disponível</p><h2>Bora editar seu próximo vídeo?</h2><p>Me chama em um desses canais e conta o que você precisa: tipo de vídeo, quantidade e prazo. A gente acerta os detalhes por lá.</p><div className="contact-links"><a href="https://wa.me/5511986890206" target="_blank" rel="noreferrer"><small>WhatsApp</small><strong>(11) 98689-0206</strong></a><a href="https://instagram.com/neskyzz_editor" target="_blank" rel="noreferrer"><small>Instagram</small><strong>@neskyzz_editor</strong></a><a href="https://x.com/neskyzz_editor" target="_blank" rel="noreferrer"><small>X / Twitter</small><strong>@neskyzz_editor</strong></a></div></div></section>
      </main>

      <footer className="site-footer"><div><a className="wordmark" href="#top">NESKY<span>_EDITOR</span></a><p>Edição de vídeos longos e cortes verticais.</p></div><div className="footer-nav"><div><a href="#trabalhos">Trabalhos</a><a href="#antes-depois">Antes / Depois</a><a href="#servicos">O que eu faço</a><a href="#processo">Processo</a><a href="#contato">Contato</a></div><div><a href="https://wa.me/5511986890206">WhatsApp</a><a href="https://instagram.com/neskyzz_editor">Instagram</a><a href="https://x.com/neskyzz_editor">X / Twitter</a></div></div><small>© 2026 nesky_editor <a className="footer-admin-link" href="/admin" aria-label="Acessar painel administrativo">· Painel</a></small></footer>
      {selected && <VideoModal item={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
