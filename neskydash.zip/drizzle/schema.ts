import { bigint, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const clients = mysqlTable("clients", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 40 }),
  status: mysqlEnum("status", ["active", "paused", "archived"]).default("active").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const videos = mysqlTable("videos", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 220 }).notNull(),
  description: text("description"),
  clientId: int("clientId"),
  category: mysqlEnum("category", ["square", "horizontal", "vertical", "before_after", "other"]).default("other").notNull(),
  status: mysqlEnum("status", ["pending", "editing", "review", "delivered"]).default("pending").notNull(),
  sourceType: mysqlEnum("sourceType", ["upload", "youtube", "portfolio"]).default("upload").notNull(),
  sourceUrl: text("sourceUrl"),
  fileKey: text("fileKey"),
  thumbnailKey: text("thumbnailKey"),
  fileName: varchar("fileName", { length: 255 }),
  fileSize: bigint("fileSize", { mode: "number" }),
  mimeType: varchar("mimeType", { length: 120 }),
  duration: int("duration"),
  aspectRatio: varchar("aspectRatio", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  deliveredAt: timestamp("deliveredAt"),
});

export const activityLogs = mysqlTable("activityLogs", {
  id: int("id").autoincrement().primaryKey(),
  type: mysqlEnum("type", ["upload", "client", "status", "youtube", "system"]).default("system").notNull(),
  message: varchar("message", { length: 255 }).notNull(),
  videoId: int("videoId"),
  clientId: int("clientId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Client = typeof clients.$inferSelect;
export type Video = typeof videos.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;
