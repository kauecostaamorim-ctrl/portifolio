CREATE TABLE `activityLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`type` enum('upload','client','status','youtube','system') NOT NULL DEFAULT 'system',
	`message` varchar(255) NOT NULL,
	`videoId` int,
	`clientId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activityLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `clients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`email` varchar(320),
	`phone` varchar(40),
	`status` enum('active','paused','archived') NOT NULL DEFAULT 'active',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `clients_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `videos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(220) NOT NULL,
	`description` text,
	`clientId` int,
	`category` enum('square','horizontal','vertical','before_after','other') NOT NULL DEFAULT 'other',
	`status` enum('pending','editing','review','delivered') NOT NULL DEFAULT 'pending',
	`sourceType` enum('upload','youtube','portfolio') NOT NULL DEFAULT 'upload',
	`sourceUrl` text,
	`fileKey` text,
	`thumbnailKey` text,
	`fileName` varchar(255),
	`fileSize` bigint,
	`mimeType` varchar(120),
	`duration` int,
	`aspectRatio` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`deliveredAt` timestamp,
	CONSTRAINT `videos_id` PRIMARY KEY(`id`)
);
