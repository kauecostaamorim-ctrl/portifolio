export default {
  logoUrl: "https://media.base44.com/images/public/builder-assets/symbol-orange.png",
};
